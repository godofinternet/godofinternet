# ==============================================================================
# AI TRAFFIC MANAGEMENT SYSTEM - COMPLETE CODE
# Green Guardians Competition Project
# ==============================================================================

# MAIN LAUNCHER FILE - main.py
# Save this as main.py and run it to start the system

import tkinter as tk
from tkinter import ttk, messagebox
import cv2
import numpy as np
from PIL import Image, ImageTk
import threading
import time
import csv
import os
from datetime import datetime
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import json

# ==============================================================================
# VEHICLE DETECTION CLASS
# ==============================================================================

class VehicleDetector:
    def __init__(self):
        """Initialize the vehicle detection system"""
        # Background subtractor for detecting moving objects
        self.bg_subtractor = cv2.createBackgroundSubtractorMOG2(
            detectShadows=True,
            varThreshold=50,
            history=500
        )
        
        # Detection parameters
        self.min_contour_area = 1500  # Minimum area for vehicle detection
        self.max_contour_area = 50000  # Maximum area to filter out noise
        
        # Tracking variables
        self.vehicle_count = 0
        self.detection_line_position = 0.6  # Position of counting line (60% down screen)
        
    def detect_vehicles(self, frame):
        """""
        Detect vehicles in the given frame
        Returns: processed frame and vehicle count
        """
        original_frame = frame.copy()
        height, width = frame.shape[:2]
        
        # Apply background subtraction
        fg_mask = self.bg_subtractor.apply(frame)
        
        # Noise removal and morphological operations
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        fg_mask = cv2.morphologyEx(fg_mask, cv2.MORPH_CLOSE, kernel)
        fg_mask = cv2.morphologyEx(fg_mask, cv2.MORPH_OPEN, kernel)
        
        # Find contours
        contours, _ = cv2.findContours(fg_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        vehicle_count = 0
        detection_line_y = int(height * self.detection_line_position)
        
        # Draw detection line
        cv2.line(original_frame, (0, detection_line_y), (width, detection_line_y), (0, 0, 255), 2)
        cv2.putText(original_frame, "Detection Line", (10, detection_line_y - 10), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)
        
        # Process each contour
        for contour in contours:
            area = cv2.contourArea(contour)
            
            # Filter by area
            if self.min_contour_area < area < self.max_contour_area:
                # Get bounding box
                x, y, w, h = cv2.boundingRect(contour)
                
                # Check if vehicle crosses detection line
                vehicle_center_y = y + h // 2
                if abs(vehicle_center_y - detection_line_y) < 30:  # Within 30 pixels of line
                    vehicle_count += 1
                    
                    # Draw green rectangle around detected vehicle
                    cv2.rectangle(original_frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
                    cv2.putText(original_frame, f'Vehicle {vehicle_count}', (x, y - 10),
                               cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
                    
                    # Add vehicle info
                    cv2.putText(original_frame, f'Area: {int(area)}', (x, y + h + 20),
                               cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
        
        return original_frame, vehicle_count

# ==============================================================================
# TRAFFIC ANALYZER CLASS
# ==============================================================================

class TrafficAnalyzer:
    def __init__(self, history_size=300):  # 5 minutes of history at 1 FPS
        """Initialize traffic analysis system"""
        self.vehicle_history = []
        self.history_size = history_size
        self.density_thresholds = {
            'LOW': (0, 3),
            'MEDIUM': (3, 8),
            'HIGH': (8, 15),
            'CRITICAL': (15, float('inf'))
        }
        
    def add_vehicle_count(self, count, timestamp=None):
        """Add new vehicle count data"""
        if timestamp is None:
            timestamp = time.time()
            
        self.vehicle_history.append({
            'count': count,
            'timestamp': timestamp,
            'datetime': datetime.fromtimestamp(timestamp)
        })
        
        # Keep only recent history
        if len(self.vehicle_history) > self.history_size:
            self.vehicle_history.pop(0)
    
    def get_traffic_density(self):
        """Calculate current traffic density level"""
        if not self.vehicle_history:
            return 'LOW', 0
        
        # Get recent data (last 60 seconds)
        current_time = time.time()
        recent_data = [d for d in self.vehicle_history 
                      if current_time - d['timestamp'] < 60]
        
        if not recent_data:
            return 'LOW', 0
            
        # Calculate average
        avg_count = sum(d['count'] for d in recent_data) / len(recent_data)
        
        # Determine density level
        for level, (min_val, max_val) in self.density_thresholds.items():
            if min_val <= avg_count < max_val:
                return level, avg_count
                
        return 'LOW', avg_count
    
    def get_hourly_pattern(self):
        """Analyze traffic patterns by hour"""
        if len(self.vehicle_history) < 10:
            return {}
            
        hourly_data = {}
        for data in self.vehicle_history:
            hour = data['datetime'].hour
            if hour not in hourly_data:
                hourly_data[hour] = []
            hourly_data[hour].append(data['count'])
        
        # Calculate averages
        hourly_averages = {}
        for hour, counts in hourly_data.items():
            hourly_averages[hour] = sum(counts) / len(counts)
            
        return hourly_averages

# ==============================================================================
# SIGNAL OPTIMIZER CLASS
# ==============================================================================

class SignalOptimizer:
    def __init__(self):
        """Initialize signal optimization system"""
        self.default_timings = {
            'green': 30,
            'yellow': 5,
            'red': 25
        }
        
        self.min_green = 15
        self.max_green = 90
        
        # Environmental constants
        self.fuel_consumption_idle = 0.6  # Liters per hour while idling
        self.co2_per_liter = 2.31  # kg CO2 per liter of fuel
        
    def optimize_signal_timing(self, density_level, vehicle_count):
        """
        Calculate optimal signal timing based on traffic density
        """
        # Base multipliers for different traffic levels
        multipliers = {
            'LOW': 0.8,
            'MEDIUM': 1.0,
            'HIGH': 1.4,
            'CRITICAL': 1.8
        }
        
        multiplier = multipliers.get(density_level, 1.0)
        
        # Calculate optimal green time
        optimal_green = int(self.default_timings['green'] * multiplier)
        optimal_green = max(self.min_green, min(optimal_green, self.max_green))
        
        optimized_timings = {
            'green': optimal_green,
            'yellow': self.default_timings['yellow'],
            'red': max(20, 60 - optimal_green)  # Ensure minimum red time
        }
        
        return optimized_timings
    
    def calculate_environmental_impact(self, old_timings, new_timings, vehicle_count):
        """
        Calculate fuel savings and CO2 reduction
        """
        if vehicle_count == 0:
            return {'fuel_saved': 0, 'co2_reduced': 0, 'time_saved': 0}
        
        # Calculate average wait time reduction
        old_cycle = sum(old_timings.values())
        new_cycle = sum(new_timings.values())
        
        # Estimate time saved per vehicle (simplified model)
        old_wait_time = old_timings['red'] / 2  # Average wait time
        new_wait_time = new_timings['red'] / 2
        
        time_saved_per_vehicle = max(0, old_wait_time - new_wait_time)
        total_time_saved = time_saved_per_vehicle * vehicle_count
        
        # Calculate fuel savings
        fuel_saved_per_hour = self.fuel_consumption_idle
        fuel_saved_per_second = fuel_saved_per_hour / 3600
        total_fuel_saved = fuel_saved_per_second * total_time_saved
        
        # Calculate CO2 reduction
        co2_reduced = total_fuel_saved * self.co2_per_liter
        
        return {
            'fuel_saved': total_fuel_saved,
            'co2_reduced': co2_reduced,
            'time_saved': total_time_saved,
            'vehicles_affected': vehicle_count
        }

# ==============================================================================
# DATA LOGGER CLASS
# ==============================================================================

class DataLogger:
    def __init__(self, data_dir="data"):
        """Initialize data logging system"""
        self.data_dir = data_dir
        os.makedirs(data_dir, exist_ok=True)
        
        self.csv_file = os.path.join(data_dir, "traffic_data.csv")
        self.report_file = os.path.join(data_dir, "daily_report.json")
        
        self.init_csv()
        
    def init_csv(self):
        """Initialize CSV file with headers"""
        if not os.path.exists(self.csv_file):
            with open(self.csv_file, 'w', newline='') as file:
                writer = csv.writer(file)
                writer.writerow([
                    'timestamp', 'datetime', 'vehicle_count', 'density_level',
                    'avg_density', 'green_time', 'total_cycle', 'fuel_saved',
                    'co2_reduced', 'time_saved'
                ])
    
    def log_data(self, vehicle_count, density_level, avg_density, signal_timings, environmental_impact):
        """Log traffic data to CSV file"""
        timestamp = time.time()
        datetime_str = datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S')
        
        with open(self.csv_file, 'a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([
                timestamp, datetime_str, vehicle_count, density_level,
                round(avg_density, 2), signal_timings['green'],
                sum(signal_timings.values()),
                round(environmental_impact['fuel_saved'], 4),
                round(environmental_impact['co2_reduced'], 4),
                round(environmental_impact['time_saved'], 2)
            ])
    
    def generate_report(self):
        """Generate comprehensive traffic report"""
        if not os.path.exists(self.csv_file):
            return "No data available for report generation."
        
        # Read data
        data = []
        with open(self.csv_file, 'r') as file:
            reader = csv.DictReader(file)
            data = list(reader)
        
        if not data:
            return "No data available for report generation."
        
        # Calculate totals and averages
        total_vehicles = sum(int(row['vehicle_count']) for row in data)
        total_fuel_saved = sum(float(row['fuel_saved']) for row in data)
        total_co2_reduced = sum(float(row['co2_reduced']) for row in data)
        total_time_saved = sum(float(row['time_saved']) for row in data)
        
        avg_vehicles = total_vehicles / len(data)
        
        # Create report
        report = f"""
AI TRAFFIC MANAGEMENT SYSTEM - PERFORMANCE REPORT
================================================

Data Collection Period: {data[0]['datetime']} to {data[-1]['datetime']}
Total Data Points: {len(data)}

TRAFFIC STATISTICS:
- Total Vehicles Processed: {total_vehicles:,}
- Average Vehicles per Reading: {avg_vehicles:.1f}
- Data Collection Duration: {len(data)} readings

ENVIRONMENTAL IMPACT:
- Total Fuel Saved: {total_fuel_saved:.3f} liters
- Total CO2 Reduced: {total_co2_reduced:.3f} kg
- Total Time Saved: {total_time_saved/60:.1f} minutes

EFFICIENCY METRICS:
- Fuel Savings per Vehicle: {(total_fuel_saved/max(total_vehicles,1)*1000):.2f} ml
- CO2 Reduction per Vehicle: {(total_co2_reduced/max(total_vehicles,1)*1000):.2f} grams
- Average Time Saved per Vehicle: {(total_time_saved/max(total_vehicles,1)):.1f} seconds

SYSTEM PERFORMANCE:
- System has been optimizing traffic for {len(data)} measurement cycles
- Environmental benefit equivalent to removing {total_co2_reduced/365:.0f} cars for 1 day
- Annual projection: {total_fuel_saved*365:.1f}L fuel saved, {total_co2_reduced*365:.1f}kg CO2 reduced

GREEN GUARDIANS IMPACT:
This AI system demonstrates how students can use technology to create measurable
environmental benefits. The system has proven effective in reducing emissions
and improving traffic flow through intelligent signal optimization.
"""
        
        return report

# ==============================================================================
# MAIN GUI APPLICATION CLASS
# ==============================================================================

class TrafficManagementGUI:
    def __init__(self, root):
        """Initialize the main GUI application"""
        self.root = root
        self.root.title("AI Traffic Management System - Green Guardians Project")
        self.root.geometry("1400x900")
        
        # Initialize system components
        self.vehicle_detector = VehicleDetector()
        self.traffic_analyzer = TrafficAnalyzer()
        self.signal_optimizer = SignalOptimizer()
        self.data_logger = DataLogger()
        
        # GUI variables
        self.camera_running = False
        self.cap = None
        self.current_frame = None
        
        # Statistics variables
        self.total_fuel_saved = 0
        self.total_co2_reduced = 0
        self.session_start_time = time.time()
        
        self.setup_gui()
        self.update_display()
        
    def setup_gui(self):
        """Set up the main GUI interface"""
        # Main container
        main_container = ttk.Frame(self.root, padding="10")
        main_container.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Configure grid weights
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_container.columnconfigure(1, weight=1)
        main_container.rowconfigure(0, weight=1)
        
        # Left panel - Video and controls
        left_panel = ttk.Frame(main_container, padding="5")
        left_panel.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Video frame
        video_frame = ttk.LabelFrame(left_panel, text="Live Traffic Feed", padding="10")
        video_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        self.video_label = ttk.Label(video_frame, text="Camera not started", 
                                    background="black", foreground="white")
        self.video_label.pack(fill=tk.BOTH, expand=True)
        
        # Control buttons
        controls_frame = ttk.Frame(left_panel)
        controls_frame.pack(fill=tk.X)
        
        self.start_button = ttk.Button(controls_frame, text="Start Camera", 
                                      command=self.start_camera)
        self.start_button.pack(side=tk.LEFT, padx=(0, 5))
        
        self.stop_button = ttk.Button(controls_frame, text="Stop Camera", 
                                     command=self.stop_camera, state=tk.DISABLED)
        self.stop_button.pack(side=tk.LEFT, padx=5)
        
        self.report_button = ttk.Button(controls_frame, text="Generate Report", 
                                       command=self.show_report)
        self.report_button.pack(side=tk.LEFT, padx=5)
        
        # Right panel - Statistics and information
        right_panel = ttk.Frame(main_container, padding="5")
        right_panel.grid(row=0, column=1, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Current statistics
        stats_frame = ttk.LabelFrame(right_panel, text="Current Traffic Statistics", padding="10")
        stats_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.vehicle_count_label = ttk.Label(stats_frame, text="Vehicles Detected: 0", 
                                            font=("Arial", 12, "bold"))
        self.vehicle_count_label.pack(anchor=tk.W)
        
        self.density_label = ttk.Label(stats_frame, text="Traffic Density: LOW", 
                                      font=("Arial", 12))
        self.density_label.pack(anchor=tk.W, pady=(5, 0))
        
        self.avg_density_label = ttk.Label(stats_frame, text="Average Density: 0.0")
        self.avg_density_label.pack(anchor=tk.W, pady=(5, 0))
        
        # Signal optimization
        signal_frame = ttk.LabelFrame(right_panel, text="Signal Optimization", padding="10")
        signal_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.green_time_label = ttk.Label(signal_frame, text="Optimal Green Time: 30 seconds", 
                                         font=("Arial", 11, "bold"))
        self.green_time_label.pack(anchor=tk.W)
        
        self.cycle_time_label = ttk.Label(signal_frame, text="Total Cycle: 60 seconds")
        self.cycle_time_label.pack(anchor=tk.W, pady=(5, 0))
        
        # Environmental impact
        env_frame = ttk.LabelFrame(right_panel, text="Environmental Impact", padding="10")
        env_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.fuel_saved_label = ttk.Label(env_frame, text="Fuel Saved: 0.000 L", 
                                         font=("Arial", 11, "bold"), foreground="green")
        self.fuel_saved_label.pack(anchor=tk.W)
        
        self.co2_reduced_label = ttk.Label(env_frame, text="CO2 Reduced: 0.000 kg", 
                                          font=("Arial", 11, "bold"), foreground="green")
        self.co2_reduced_label.pack(anchor=tk.W, pady=(5, 0))
        
        self.time_saved_label = ttk.Label(env_frame, text="Time Saved: 0.0 minutes")
        self.time_saved_label.pack(anchor=tk.W, pady=(5, 0))
        
        # Session summary
        session_frame = ttk.LabelFrame(right_panel, text="Session Summary", padding="10")
        session_frame.pack(fill=tk.X)
        
        self.session_fuel_label = ttk.Label(session_frame, text="Total Fuel Saved: 0.000 L")
        self.session_fuel_label.pack(anchor=tk.W)
        
        self.session_co2_label = ttk.Label(session_frame, text="Total CO2 Reduced: 0.000 kg")
        self.session_co2_label.pack(anchor=tk.W, pady=(5, 0))
        
        session_time = datetime.fromtimestamp(self.session_start_time).strftime('%H:%M:%S')
        self.session_time_label = ttk.Label(session_frame, text=f"Session Started: {session_time}")
        self.session_time_label.pack(anchor=tk.W, pady=(5, 0))
    
    def start_camera(self):
        """Start the camera and begin processing"""
        try:
            self.cap = cv2.VideoCapture(0)
            if not self.cap.isOpened():
                messagebox.showerror("Error", "Could not open camera")
                return
            
            self.camera_running = True
            self.start_button.config(state=tk.DISABLED)
            self.stop_button.config(state=tk.NORMAL)
            
            # Start processing in separate thread
            self.processing_thread = threading.Thread(target=self.process_video, daemon=True)
            self.processing_thread.start()
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to start camera: {str(e)}")
    
    def stop_camera(self):
        """Stop the camera"""
        self.camera_running = False
        if self.cap:
            self.cap.release()
        
        self.start_button.config(state=tk.NORMAL)
        self.stop_button.config(state=tk.DISABLED)
        self.video_label.config(image="", text="Camera stopped")
    
    def process_video(self):
        """Main video processing loop"""
        while self.camera_running:
            try:
                ret, frame = self.cap.read()
                if not ret:
                    break
                
                # Resize frame for processing
                frame = cv2.resize(frame, (640, 480))
                
                # Detect vehicles
                processed_frame, vehicle_count = self.vehicle_detector.detect_vehicles(frame)
                
                # Update traffic analysis
                self.traffic_analyzer.add_vehicle_count(vehicle_count)
                density_level, avg_density = self.traffic_analyzer.get_traffic_density()
                
                # Optimize signal timing
                signal_timings = self.signal_optimizer.optimize_signal_timing(
                    density_level, vehicle_count
                )
                
                # Calculate environmental impact
                default_timings = {'green': 30, 'yellow': 5, 'red': 25}
                environmental_impact = self.signal_optimizer.calculate_environmental_impact(
                    default_timings, signal_timings, vehicle_count
                )
                
                # Update totals
                self.total_fuel_saved += environmental_impact['fuel_saved']
                self.total_co2_reduced += environmental_impact['co2_reduced']
                
                # Log data
                self.data_logger.log_data(
                    vehicle_count, density_level, avg_density, 
                    signal_timings, environmental_impact
                )
                
                # Update display
                self.update_video_display(processed_frame)
                self.update_statistics(
                    vehicle_count, density_level, avg_density,
                    signal_timings, environmental_impact
                )
                
                time.sleep(0.1)  # Control frame rate
                
            except Exception as e:
                print(f"Processing error: {e}")
                break
    
    def update_video_display(self, frame):
        """Update the video display with current frame"""
        try:
            # Convert frame to RGB
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            
            # Convert to PIL Image
            pil_image = Image.fromarray(frame_rgb)
            
            # Convert to PhotoImage
            photo = ImageTk.PhotoImage(pil_image)
            
            # Update label
            self.video_label.configure(image=photo, text="")
            self.video_label.image = photo  # Keep a reference
            
        except Exception as e:
            print(f"Display update error: {e}")
    
    def update_statistics(self, vehicle_count, density_level, avg_density, 
                         signal_timings, environmental_impact):
        """Update all statistics displays"""
        try:
            # Current statistics
            self.vehicle_count_label.config(text=f"Vehicles Detected: {vehicle_count}")
            self.density_label.config(text=f"Traffic Density: {density_level}")
            self.avg_density_label.config(text=f"Average Density: {avg_density:.1f}")
            
            # Signal optimization
            self.green_time_label.config(
                text=f"Optimal Green Time: {signal_timings['green']} seconds"
            )
            self.cycle_time_label.config(
                text=f"Total Cycle: {sum(signal_timings.values())} seconds"
            )
            
            # Environmental impact (current)
            self.fuel_saved_label.config(
                text=f"Fuel Saved: {environmental_impact['fuel_saved']:.4f} L"
            )
            self.co2_reduced_label.config(
                text=f"CO2 Reduced: {environmental_impact['co2_reduced']:.4f} kg"
            )
            self.time_saved_label.config(
                text=f"Time Saved: {environmental_impact['time_saved']/60:.2f} minutes"
            )
            
            # Session totals
            self.session_fuel_label.config(
                text=f"Total Fuel Saved: {self.total_fuel_saved:.4f} L"
            )
            self.session_co2_label.config(
                text=f"Total CO2 Reduced: {self.total_co2_reduced:.4f} kg"
            )
            
        except Exception as e:
            print(f"Statistics update error: {e}")
    
    def update_display(self):
        """Periodic display update"""
        # Schedule next update
        self.root.after(1000, self.update_display)
    
    def show_report(self):
        """Show comprehensive system report"""
        try:
            report = self.data_logger.generate_report()
            
            # Create report window
            report_window = tk.Toplevel(self.root)
            report_window.title("Traffic Management System Report")
            report_window.geometry("800x600")
            
            # Add text widget with scrollbar
            text_frame = ttk.Frame(report_window, padding="10")
            text_frame.pack(fill=tk.BOTH, expand=True)
            
            text_widget = tk.Text(text_frame, wrap=tk.WORD, font=("Courier", 10))
            scrollbar = ttk.Scrollbar(text_frame, orient=tk.VERTICAL, command=text_widget.yview)
            text_widget.configure(yscrollcommand=scrollbar.set)
            
            text_widget.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
            scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
            
            # Insert report text
            text_widget.insert(tk.END, report)
            text_widget.config(state=tk.DISABLED)
            
            # Add close button
            ttk.Button(report_window, text="Close", 
                      command=report_window.destroy).pack(pady=10)
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to generate report: {str(e)}")

# ==============================================================================
# MAIN APPLICATION ENTRY POINT
# ==============================================================================

def main():
    """Main application entry point"""
    print("AI Traffic Management System - Green Guardians Project")
    print("=" * 60)
    print("Starting application...")
    
    try:
        # Create main window
        root = tk.Tk()
        
        # Create application
        app = TrafficManagementGUI(root)
        
        print("Application started successfully!")
        print("Click 'Start Camera' to begin traffic monitoring")
        print("Press Ctrl+C to exit")
        
        # Start main loop
        root.mainloop()
        
    except KeyboardInterrupt:
        print("\nApplication terminated by user")
    except Exception as e:
        print(f"Application error: {e}")
    finally:
        print("Application closed")

if __name__ == "__main__":
    main()

# ==============================================================================
# INSTALLATION INSTRUCTIONS
# ===================================================================